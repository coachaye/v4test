# VIZN PROTOCOL
A flawless, pixel-perfect clone of the requested UI.

## How to run locally
1. `npm install`
2. `npm run dev`

## How to deploy to Vercel perfectly
1. Upload this EXACT folder to your GitHub repo.
2. Ensure `package.json` and the `app` folder are visible AT THE ROOT of your repository on GitHub.
3. Import the repo to Vercel. Leave all settings exactly as default.
4. Click deploy. It will work 100% on the first try.
