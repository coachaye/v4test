import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        brand: {
          DEFAULT: "#156c5d",
          hover: "#105448",
        },
        background: {
          DEFAULT: "#eef5f6",
        }
      },
      fontFamily: {
        mono: ["var(--font-space-mono)", "monospace"],
        cursive: ["var(--font-caveat)", "cursive"],
      },
      boxShadow: {
        'soft': '0 20px 40px -15px rgba(21, 108, 93, 0.15)',
      }
    },
  },
  plugins: [],
};
export default config;