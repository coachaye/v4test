import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import NorthStar from "@/components/NorthStar";

export default function Home() {
  return (
    <main className="min-h-screen relative overflow-x-hidden">
      <Navbar />
      <Hero />
      <NorthStar />
    </main>
  );
}